# %%
from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit

# %%
from qiskit_aer import AerSimulator
import numpy as np

# %%
# Quantum Random Bit Generator
def generate_random_bits(qubits=3, shots=1000, simulator=None, circ=None):
    if simulator is None:
        simulator = AerSimulator()
    
    if circ is None:
        # Create quantum and classical registers
        q = QuantumRegister(qubits, 'q')
        c = ClassicalRegister(qubits, 'c')
        circ = QuantumCircuit(q, c)
        
        # Apply Hadamard gate to each qubit to create superposition
        for i in range(qubits):
            circ.h(q[i])
        
        # Measure the qubits
        circ.measure(q, c)

    # Use AerSimulator to run the circuit
    job = simulator.run(circ, shots=shots)
    result = job.result()
    counts = result.get_counts(circ)
    
    # Convert the counts into a list of bits
    bits = []
    for bitstring, count in counts.items():
        bits.extend([bit for _ in range(count) for bit in bitstring])
    
    return bits

# %%
# Generate random bits using 3 qubits and 100,000 shots
simulator = AerSimulator()
q = QuantumRegister(3, 'q')
c = ClassicalRegister(3, 'c')
circ = QuantumCircuit(q, c)
for i in range(3):
    circ.h(q[i])
circ.measure(q, c)

# Collect 100,000 binary bits
total_bits = []
while len(total_bits) < 100000:
    total_bits.extend(generate_random_bits(3, shots=1000, simulator=simulator, circ=circ))

# %%
# Truncate to exactly 100,000 bits
total_bits = total_bits[:100000]

# Print the first 100 bits for validation
print(f"First 1000000 bits: {''.join(total_bits[:100000])}")

# Save the bits to a text file
with open('quantum_random_bits.txt', 'w') as f:
    f.write(''.join(total_bits))

print(f"Generated 100,000 random bits and saved to 'quantum_random_bits.txt'.")

# %%



